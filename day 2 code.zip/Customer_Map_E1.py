# -*- coding: utf-8 -*-
"""
Title: Customer Map on demographics Data solutions for Exercise 1
Author: Patrick Glettig
Date: 17.11.2018
"""
import os
import pandas as pd
import dash
import dash_core_components as dcc
import dash_html_components as html
import plotly.plotly as py

os.chdir('C:/Users/patri/Dropbox/Python Advanced - Slides & Code/data')

demographics = pd.read_csv('demographics.csv')
demographics["Birthdate"] = pd.to_datetime(demographics["Birthdate"],
                                            format="%d.%m.%Y",
                                            utc=True,
                                            dayfirst=True)

demographics["JoinDate"] = pd.to_datetime(demographics["JoinDate"],
                                            format="%d.%m.%Y",
                                            utc=True,
                                            dayfirst=True)

demographics["CustomerCount"] = demographics.groupby(["zip_city"], as_index=False)["Customer"].transform("count")

customerCount = demographics['CustomerCount'].tolist()
zipcity = demographics['zip_city'].tolist()
hovertext = []
for i in range(len(customerCount)):
    k = str(zipcity[i]) + ':' + str(customerCount[i])
    hovertext.append(k)

def makeMap():
    return (dcc.Graph(id='scatterplot',
                                 figure = {'data':[dict(
                                                     type = 'scattergeo',
                                                     locationmode = 'USA-states',
                                                     lon = demographics['zip_longitude'],
                                                     lat = demographics['zip_latitude'],
                                                     text = hovertext,
                                                     hoverinfo = 'text',
                                                     marker = dict(
                                                                 size = demographics['CustomerCount'],
                                                                 line = dict(width=0.5, color='rgb(40,40,40)'),
                                                                 sizemode = 'area'
                                                                  ),
                                                     transforms = [dict(
                                                                        type = 'aggregate',
                                                                        groups = demographics['zip_city'],
                                                                        aggregations = [dict(target = demographics['Customer'], func = 'count', enabled = True)]
                                                                        )
                                                                    ]
                                                        )
                                                     ]
                                        }
                                    ))
                        

app = dash.Dash()

#Add the CSS Stylesheet
app.css.append_css({'external_url': 'https://codepen.io/chriddyp/pen/bWLwgP.css'})

app.layout = html.Div([html.H1('Customer Map', style={'textAlign':'center'}), #add a title
                       #Add the Sidebarlayout here
                      html.Div(children=[html.Div([html.H3('Inputs')], className = "one columns"),
                                         html.Div([makeMap()], className = "eleven columns")
                                         ]
                                )
                      ])

if __name__ == '__main__':
    app.run_server()