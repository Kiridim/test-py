"""
####################################################################
Basic Structure of a Dash App
####################################################################
"""

import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output #this is for the callback functionality

app = dash.Dash()

"""
User Interface
"""
app.layout = html.Div([
                dcc.Input(id='PLACEHOLDER',value='Initial Text',type='text'),#input component
                html.Div(id='PLACEHOLDER',style={'border':'2px blue solid'})
])
"""
Backend
"""
#Here we link the input to a part of our layout, namely my-div. Do this using decorator @app.callback
@app.callback(Output(component_id='PLACEHOLDER',component_property='children'),#define to which component and to which property of the component it goes.
              #children is just the default property of html.Div
              #Input is defined as a list
              [Input(component_id='PLACEHOLDER',component_property='value')])

#here we define how the value gets updated. We create a function for this
def update_output_div(input_value):
    return "PLACEHOLDER: {}".format(input_value)#.format feeds the value to the {}

if __name__ == '__main__':
    app.run_server()